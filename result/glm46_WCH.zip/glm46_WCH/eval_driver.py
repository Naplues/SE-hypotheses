"""Reuse locally retagged official eval images (skip env/instance image builds).

Run from output/glm46_CH/; report json and logs/ land in that directory.
"""
import docker
from swebench.harness import docker_build, run_evaluation


def _no_build_env_images(*args, **kwargs):
    print("[driver] skipping env image builds - reusing existing instance images")
    return [], []


_orig_build_instance_image = docker_build.build_instance_image


def _build_instance_image_if_missing(test_spec, client, logger, nocache):
    try:
        client.images.get(test_spec.instance_image_key)
        logger.info(
            f"Instance image {test_spec.instance_image_key} already exists, skipping build"
        )
        return
    except docker.errors.ImageNotFound:
        pass
    # 官方预构建镜像即成品实例镜像：缺标签时直接转标签，绝不本地构建
    src = f"swebench/sweb.eval.x86_64.{test_spec.instance_id.replace('__', '_1776_')}"
    tag = test_spec.instance_image_key.split(":")[0]
    try:
        client.images.get(src)
        client.api.tag(src, tag, "latest")
        logger.info(f"[driver] retagged {src} -> {tag}:latest instead of building")
        return
    except docker.errors.ImageNotFound:
        logger.warning(f"[driver] no source image {src}, falling back to build")
    return _orig_build_instance_image(test_spec, client, logger, nocache)


run_evaluation.build_env_images = _no_build_env_images
docker_build.build_env_images = _no_build_env_images
docker_build.build_instance_image = _build_instance_image_if_missing

if __name__ == "__main__":
    run_evaluation.main(
        dataset_name="../../data/swe-bench-verified_test_WCH.json",
        split="test",
        instance_ids=None,
        predictions_path="./mini_run/preds_list.json",
        max_workers=4,
        force_rebuild=False,
        cache_level="env",
        clean=False,
        open_file_limit=4096,
        run_id="glm46_WCH_run_01",
        timeout=1800,
    )
